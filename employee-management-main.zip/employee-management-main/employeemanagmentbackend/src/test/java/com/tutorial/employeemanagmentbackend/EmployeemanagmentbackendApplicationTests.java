package com.tutorial.employeemanagmentbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeemanagmentbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
